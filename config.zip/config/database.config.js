// require('dotenv').config();

module.exports = {
    host: process.env.DB_HOST || 'drona.db.elephantsql.com',
    database: process.env.DB_DATABASE || 'gvoxswxl',
    username: process.env.DB_USERNAME || 'gvoxswxl',
    password: process.env.DB_PASSWORD || 'sfyIqR4E6CdtyIeGFc_LigDQQHhY-6Y3'
}